# webman-websafe

#### 介绍
webman、workerman可用的WEB应用层防火墙

#### 软件架构
PHP开发，配合webman的请求类获取请求数据


#### 使用说明

1.  只能在webman使用
2.  PHP版本>=7.2

