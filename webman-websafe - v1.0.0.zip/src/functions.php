<?php

use Workerman\Events\Event;

Event::class;
